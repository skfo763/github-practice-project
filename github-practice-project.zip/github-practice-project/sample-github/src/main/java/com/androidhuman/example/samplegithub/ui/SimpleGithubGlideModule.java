package com.androidhuman.example.samplegithub.ui;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

@GlideModule
public class SimpleGithubGlideModule extends AppGlideModule {
    // Intentionally left blank
}
